import Foundation

struct TodoistTask: Codable, Identifiable, Hashable, Sendable {
    let id: String
    let projectId: String
    let sectionId: String?
    let parentId: String?
    let content: String
    let description: String
    let labels: [String]
    let priority: Int
    let due: TodoistDue?
    let url: URL?

    var dueDate: Date? {
        due?.resolvedDate
    }
}

struct TodoistDue: Codable, Hashable, Sendable {
    let date: String
    let string: String
    let lang: String?
    let isRecurring: Bool
    let datetime: String?
    let timezone: String?

    var resolvedDate: Date? {
        if let datetime {
            if let parsed = ISO8601DateFormatter.todoistFractional.date(from: datetime) {
                return parsed
            }
            if let parsed = ISO8601DateFormatter.todoistStandard.date(from: datetime) {
                return parsed
            }
        }

        return DateFormatter.todoistDay.date(from: date)
    }
}

struct TodoistProject: Codable, Identifiable, Hashable, Sendable {
    let id: String
    let name: String
    let color: String?
    let parentId: String?
    let isFavorite: Bool
    let isInboxProject: Bool
    let isShared: Bool
    let url: URL?
}

struct PaginatedResponse<Value: Decodable>: Decodable {
    let results: [Value]
    let nextCursor: String?
}

private extension ISO8601DateFormatter {
    static let todoistFractional: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return formatter
    }()

    static let todoistStandard: ISO8601DateFormatter = {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime]
        return formatter
    }()
}

private extension DateFormatter {
    static let todoistDay: DateFormatter = {
        let formatter = DateFormatter()
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
}
