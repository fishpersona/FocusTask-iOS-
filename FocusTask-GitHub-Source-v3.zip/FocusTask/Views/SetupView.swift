import SwiftUI

struct SetupView: View {
    @EnvironmentObject private var appState: AppState

    @State private var token = ""
    @State private var isConnecting = false
    @FocusState private var tokenIsFocused: Bool

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 28) {
                    Image(systemName: "timer.circle.fill")
                        .font(.system(size: 78))
                        .symbolRenderingMode(.palette)
                        .foregroundStyle(.white, Color.accentColor)
                        .padding(.top, 36)

                    VStack(spacing: 10) {
                        Text("FocusTask")
                            .font(.largeTitle.bold())
                        Text("Choose a Todoist task, focus on it, and keep a private record of the time you invested.")
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Connect Todoist")
                            .font(.headline)

                        SecureField("Personal API token", text: $token)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled()
                            .focused($tokenIsFocused)
                            .submitLabel(.go)
                            .onSubmit(connect)
                            .padding(14)
                            .background(.secondary.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))

                        if let error = appState.connectionError {
                            Label(error, systemImage: "exclamationmark.triangle.fill")
                                .font(.footnote)
                                .foregroundStyle(.red)
                        }

                        Button(action: connect) {
                            HStack {
                                if isConnecting {
                                    ProgressView()
                                        .tint(.white)
                                }
                                Text(isConnecting ? "Checking Token…" : "Connect")
                            }
                            .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)
                        .disabled(token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isConnecting)

                        Text("Find the token in Todoist → Settings → Integrations → Developer. It is verified with Todoist and then stored only in this iPhone's Keychain.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(20)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
                }
                .padding(.horizontal, 22)
                .frame(maxWidth: 600)
                .frame(maxWidth: .infinity)
            }
            .navigationTitle("Welcome")
            .navigationBarTitleDisplayMode(.inline)
        }
    }

    private func connect() {
        guard !isConnecting else { return }
        tokenIsFocused = false
        isConnecting = true
        Task {
            let connected = await appState.connect(token: token)
            if connected { token = "" }
            isConnecting = false
        }
    }
}

