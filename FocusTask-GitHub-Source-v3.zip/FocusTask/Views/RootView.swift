import Foundation
import SwiftData
import SwiftUI

struct RootView: View {
    @EnvironmentObject private var appState: AppState
    @ObservedObject var timer: TimerEngine

    var body: some View {
        Group {
            if appState.isConnected {
                MainTabView(timer: timer)
            } else {
                SetupView()
            }
        }
        .animation(.easeInOut(duration: 0.2), value: appState.isConnected)
    }
}

private struct MainTabView: View {
    enum Tab: Hashable {
        case tasks
        case timer
        case history
        case settings
    }

    @Environment(\.modelContext) private var modelContext
    @ObservedObject var timer: TimerEngine
    @State private var selectedTab: Tab = .tasks
    @State private var persistedCompletionId: UUID?

    var body: some View {
        TabView(selection: $selectedTab) {
            TaskListView { task, projectName in
                let minutes = UserDefaults.standard.object(forKey: "focusMinutes") as? Int ?? 25
                timer.start(
                    phase: .focus,
                    minutes: minutes,
                    task: task,
                    projectName: projectName
                )
                selectedTab = .timer
            }
            .tabItem { Label("Tasks", systemImage: "checklist") }
            .tag(Tab.tasks)

            TimerView(timer: timer) {
                selectedTab = .tasks
            }
            .tabItem { Label("Timer", systemImage: "timer") }
            .tag(Tab.timer)

            HistoryView()
                .tabItem { Label("History", systemImage: "chart.bar") }
                .tag(Tab.history)

            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
                .tag(Tab.settings)
        }
        .onChange(of: timer.completion?.id) { _, _ in
            persistCompletionIfNeeded()
        }
        .task {
            persistCompletionIfNeeded()
        }
    }

    private func persistCompletionIfNeeded() {
        guard let completion = timer.completion,
              completion.id != persistedCompletionId else { return }

        let state = completion.state
        let taskTitle = state.task?.content ?? state.phase.title
        let taskId = state.task?.id
        let session = PomodoroSession(
            taskId: taskId,
            taskTitle: taskTitle,
            projectName: state.projectName,
            startedAt: state.startedAt,
            endedAt: completion.endedAt,
            plannedSeconds: state.plannedSeconds,
            completedSeconds: completion.completedSeconds,
            kind: state.phase.rawValue,
            outcome: completion.outcome
        )
        modelContext.insert(session)
        try? modelContext.save()
        persistedCompletionId = completion.id
        timer.acknowledgeCompletion()
    }
}
