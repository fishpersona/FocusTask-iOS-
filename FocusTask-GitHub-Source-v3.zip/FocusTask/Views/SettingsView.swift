import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var appState: AppState

    @AppStorage("focusMinutes") private var focusMinutes = 25
    @AppStorage("shortBreakMinutes") private var shortBreakMinutes = 5
    @AppStorage("longBreakMinutes") private var longBreakMinutes = 15

    @State private var showingDisconnectConfirmation = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Timer Lengths") {
                    Stepper("Focus: \(focusMinutes) minutes", value: $focusMinutes, in: 1...120)
                    Stepper("Short break: \(shortBreakMinutes) minutes", value: $shortBreakMinutes, in: 1...30)
                    Stepper("Long break: \(longBreakMinutes) minutes", value: $longBreakMinutes, in: 1...60)
                }

                Section {
                    LabeledContent("Status") {
                        Label("Connected", systemImage: "checkmark.circle.fill")
                            .foregroundStyle(.green)
                    }

                    Button("Disconnect Todoist", role: .destructive) {
                        showingDisconnectConfirmation = true
                    }
                } header: {
                    Text("Todoist")
                } footer: {
                    Text("Your personal API token is stored in the iOS Keychain and is never included in session history.")
                }

                Section("About") {
                    LabeledContent(
                        "Version",
                        value: Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "—"
                    )
                    Text("FocusTask is an independent personal project and is not created by, affiliated with, or supported by Todoist.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
            .confirmationDialog(
                "Disconnect Todoist?",
                isPresented: $showingDisconnectConfirmation,
                titleVisibility: .visible
            ) {
                Button("Disconnect", role: .destructive) { appState.disconnect() }
                Button("Cancel", role: .cancel) { }
            } message: {
                Text("This removes the API token from Keychain. Your local focus history will remain.")
            }
        }
    }
}
