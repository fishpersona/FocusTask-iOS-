import Foundation
import SwiftUI

struct TaskListView: View {
    @EnvironmentObject private var appState: AppState

    let onStart: (TodoistTask, String?) -> Void

    @State private var tasks: [TodoistTask] = []
    @State private var projects: [TodoistProject] = []
    @State private var selectedScope = "today"
    @State private var searchText = ""
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Group {
                if isLoading && tasks.isEmpty {
                    ProgressView("Loading Todoist…")
                } else if let errorMessage, tasks.isEmpty {
                    ContentUnavailableView {
                        Label("Couldn’t Load Tasks", systemImage: "wifi.exclamationmark")
                    } description: {
                        Text(errorMessage)
                    } actions: {
                        Button("Try Again") { Task { await refresh() } }
                            .buttonStyle(.borderedProminent)
                    }
                } else if visibleTasks.isEmpty {
                    ContentUnavailableView(
                        searchText.isEmpty ? "No Tasks Here" : "No Matching Tasks",
                        systemImage: searchText.isEmpty ? "checkmark.circle" : "magnifyingglass",
                        description: Text(emptyMessage)
                    )
                } else {
                    List(visibleTasks) { task in
                        TaskRow(
                            task: task,
                            projectName: projectName(for: task.projectId),
                            onStart: { onStart(task, projectName(for: task.projectId)) }
                        )
                    }
                    .listStyle(.plain)
                    .refreshable { await refresh() }
                }
            }
            .navigationTitle("Choose a Task")
            .searchable(text: $searchText, prompt: "Search tasks")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Picker("Task scope", selection: $selectedScope) {
                            Label("Today & Overdue", systemImage: "sun.max").tag("today")
                            Label("All Active", systemImage: "tray.full").tag("all")
                            Label("Inbox", systemImage: "tray").tag("inbox")
                            Label("Upcoming", systemImage: "calendar").tag("upcoming")

                            if !projects.isEmpty {
                                Divider()
                                ForEach(projects.filter { !$0.isInboxProject }) { project in
                                    Text(project.name).tag("project:\(project.id)")
                                }
                            }
                        }
                    } label: {
                        Label(scopeTitle, systemImage: "line.3.horizontal.decrease.circle")
                    }
                }

                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        Task { await refresh() }
                    } label: {
                        if isLoading {
                            ProgressView()
                        } else {
                            Image(systemName: "arrow.clockwise")
                        }
                    }
                    .disabled(isLoading)
                }
            }
        }
        .task {
            if tasks.isEmpty { await refresh() }
        }
    }

    private var visibleTasks: [TodoistTask] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())

        return tasks
            .filter { task in
                switch selectedScope {
                case "today":
                    guard let due = task.dueDate else { return false }
                    return calendar.startOfDay(for: due) <= today
                case "inbox":
                    return projects.first(where: { $0.isInboxProject })?.id == task.projectId
                case "upcoming":
                    guard let due = task.dueDate else { return false }
                    return calendar.startOfDay(for: due) > today
                case let scope where scope.hasPrefix("project:"):
                    return task.projectId == String(scope.dropFirst("project:".count))
                default:
                    return true
                }
            }
            .filter { task in
                guard !searchText.isEmpty else { return true }
                return task.content.localizedStandardContains(searchText)
                    || task.description.localizedStandardContains(searchText)
            }
            .sorted(by: taskSort)
    }

    private var scopeTitle: String {
        switch selectedScope {
        case "today": "Today"
        case "all": "All"
        case "inbox": "Inbox"
        case "upcoming": "Upcoming"
        default:
            if selectedScope.hasPrefix("project:"),
               let project = projects.first(where: { "project:\($0.id)" == selectedScope }) {
                project.name
            } else {
                "Tasks"
            }
        }
    }

    private var emptyMessage: String {
        if !searchText.isEmpty { return "Try a different search." }
        if selectedScope == "today" { return "Nothing is due today or overdue." }
        return "Select another list or refresh Todoist."
    }

    private func taskSort(_ lhs: TodoistTask, _ rhs: TodoistTask) -> Bool {
        switch (lhs.dueDate, rhs.dueDate) {
        case let (left?, right?) where left != right:
            return left < right
        case (nil, _?):
            return false
        case (_?, nil):
            return true
        default:
            if lhs.priority != rhs.priority { return lhs.priority > rhs.priority }
            return lhs.content.localizedStandardCompare(rhs.content) == .orderedAscending
        }
    }

    private func projectName(for id: String) -> String? {
        projects.first(where: { $0.id == id })?.name
    }

    private func refresh() async {
        guard !isLoading else { return }
        isLoading = true
        errorMessage = nil
        do {
            async let fetchedTasks = appState.todoist.fetchTasks()
            async let fetchedProjects = appState.todoist.fetchProjects()
            let (newTasks, newProjects) = try await (fetchedTasks, fetchedProjects)
            tasks = newTasks
            projects = newProjects.sorted {
                $0.name.localizedStandardCompare($1.name) == .orderedAscending
            }
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }
}

private struct TaskRow: View {
    let task: TodoistTask
    let projectName: String?
    let onStart: () -> Void

    var body: some View {
        Button(action: onStart) {
            HStack(spacing: 14) {
                priorityIndicator

                VStack(alignment: .leading, spacing: 5) {
                    Text(task.content)
                        .font(.body.weight(.medium))
                        .foregroundStyle(.primary)
                        .multilineTextAlignment(.leading)

                    HStack(spacing: 8) {
                        if let projectName {
                            Label(projectName, systemImage: "number")
                        }
                        if let due = task.dueDate {
                            Label {
                                Text(due, format: .dateTime.month(.abbreviated).day())
                            } icon: {
                                Image(systemName: "calendar")
                            }
                            .foregroundStyle(isOverdue(due) ? .red : .secondary)
                        }
                    }
                    .font(.caption)
                    .foregroundStyle(.secondary)
                }

                Spacer(minLength: 8)
                Image(systemName: "play.circle.fill")
                    .font(.title2)
                    .foregroundStyle(Color.accentColor)
            }
            .padding(.vertical, 6)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Start focus session for \(task.content)")
    }

    private var priorityIndicator: some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(priorityColor)
            .frame(width: 4, height: 36)
    }

    private var priorityColor: Color {
        switch task.priority {
        case 4: .red
        case 3: .orange
        case 2: .blue
        default: .secondary.opacity(0.25)
        }
    }

    private func isOverdue(_ due: Date) -> Bool {
        Calendar.current.startOfDay(for: due) < Calendar.current.startOfDay(for: Date())
    }
}
