import Foundation
import SwiftData
import SwiftUI

struct HistoryView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \PomodoroSession.startedAt, order: .reverse)
    private var sessions: [PomodoroSession]

    var body: some View {
        NavigationStack {
            Group {
                if sessions.isEmpty {
                    ContentUnavailableView(
                        "No Sessions Yet",
                        systemImage: "chart.bar",
                        description: Text("Completed and interrupted sessions will appear here.")
                    )
                } else {
                    List {
                        Section {
                            HStack(spacing: 0) {
                                summaryCell(value: "\(todayFocusCount)", label: "Focus sessions")
                                Divider().frame(height: 42)
                                summaryCell(value: "\(todayFocusMinutes)", label: "Minutes today")
                            }
                            .padding(.vertical, 7)
                        }

                        Section("Recent") {
                            ForEach(sessions) { session in
                                SessionRow(session: session)
                            }
                            .onDelete(perform: delete)
                        }
                    }
                }
            }
            .navigationTitle("History")
        }
    }

    private var todayCompletedFocus: [PomodoroSession] {
        sessions.filter {
            Calendar.current.isDateInToday($0.startedAt)
                && $0.kind == TimerPhase.focus.rawValue
                && $0.outcome == "completed"
        }
    }

    private var todayFocusCount: Int {
        todayCompletedFocus.count
    }

    private var todayFocusMinutes: Int {
        Int(todayCompletedFocus.reduce(0) { $0 + $1.completedSeconds } / 60)
    }

    private func summaryCell(value: String, label: String) -> some View {
        VStack(spacing: 3) {
            Text(value)
                .font(.title2.bold())
                .monospacedDigit()
            Text(label)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private func delete(at offsets: IndexSet) {
        for offset in offsets {
            modelContext.delete(sessions[offset])
        }
    }
}

private struct SessionRow: View {
    let session: PomodoroSession

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .foregroundStyle(color)
                .frame(width: 28)

            VStack(alignment: .leading, spacing: 4) {
                Text(session.taskTitle)
                    .font(.body.weight(.medium))
                    .lineLimit(2)
                HStack(spacing: 7) {
                    Text(session.startedAt, format: .dateTime.month(.abbreviated).day().hour().minute())
                    if let projectName = session.projectName {
                        Text("•")
                        Text(projectName)
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }

            Spacer()

            Text("\(Int(session.completedSeconds / 60))m")
                .font(.callout.monospacedDigit().weight(.semibold))
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 3)
    }

    private var icon: String {
        if session.outcome != "completed" { return "xmark.circle" }
        return session.kind == TimerPhase.focus.rawValue ? "brain.head.profile" : "cup.and.saucer.fill"
    }

    private var color: Color {
        if session.outcome != "completed" { return .orange }
        return session.kind == TimerPhase.focus.rawValue ? .accentColor : .green
    }
}
