import SwiftUI

struct TimerView: View {
    @EnvironmentObject private var appState: AppState
    @ObservedObject var timer: TimerEngine

    let onChooseTask: () -> Void

    @AppStorage("focusMinutes") private var focusMinutes = 25
    @AppStorage("shortBreakMinutes") private var shortBreakMinutes = 5
    @AppStorage("longBreakMinutes") private var longBreakMinutes = 15

    @State private var showingCancelConfirmation = false
    @State private var todoistMessage: String?
    @State private var isCompletingTask = false

    var body: some View {
        NavigationStack {
            Group {
                if let state = timer.state {
                    activeTimer(state)
                } else {
                    inactiveTimer
                }
            }
            .navigationTitle(timer.state?.phase.title ?? "Timer")
            .navigationBarTitleDisplayMode(.inline)
            .alert("End this session?", isPresented: $showingCancelConfirmation) {
                Button("Keep Going", role: .cancel) { }
                Button("End Session", role: .destructive) { timer.cancel() }
            } message: {
                Text("The elapsed portion will be saved as an interrupted session.")
            }
            .alert("Todoist", isPresented: Binding(
                get: { todoistMessage != nil },
                set: { if !$0 { todoistMessage = nil } }
            )) {
                Button("OK") { todoistMessage = nil }
            } message: {
                Text(todoistMessage ?? "")
            }
        }
    }

    private func activeTimer(_ state: ActiveTimerState) -> some View {
        ScrollView {
            VStack(spacing: 28) {
                VStack(spacing: 6) {
                    Text(state.phase.title.uppercased())
                        .font(.caption.bold())
                        .tracking(1.4)
                        .foregroundStyle(.secondary)

                    Text(state.task?.content ?? state.phase.title)
                        .font(.title2.bold())
                        .multilineTextAlignment(.center)
                        .lineLimit(3)
                }

                ZStack {
                    Circle()
                        .stroke(.secondary.opacity(0.15), lineWidth: 16)
                    Circle()
                        .trim(from: 0, to: timer.progress)
                        .stroke(
                            state.phase == .focus ? Color.accentColor : .green,
                            style: StrokeStyle(lineWidth: 16, lineCap: .round)
                        )
                        .rotationEffect(.degrees(-90))
                        .animation(.linear(duration: 0.2), value: timer.progress)

                    VStack(spacing: 7) {
                        Text(timer.formattedRemaining)
                            .font(.system(size: 58, weight: .semibold, design: .rounded))
                            .monospacedDigit()
                            .contentTransition(.numericText())
                        Text(state.isRunning ? "remaining" : "paused")
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(width: 270, height: 270)
                .padding(.vertical, 10)

                HStack(spacing: 14) {
                    Button {
                        showingCancelConfirmation = true
                    } label: {
                        Label("End", systemImage: "xmark")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .controlSize(.large)

                    Button {
                        state.isRunning ? timer.pause() : timer.resume()
                    } label: {
                        Label(
                            state.isRunning ? "Pause" : "Resume",
                            systemImage: state.isRunning ? "pause.fill" : "play.fill"
                        )
                        .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                }

                if state.phase == .focus, let task = state.task {
                    completeTodoistButton(task)
                }
            }
            .padding(24)
            .frame(maxWidth: 620)
            .frame(maxWidth: .infinity)
        }
    }

    private var inactiveTimer: some View {
        ScrollView {
            VStack(spacing: 24) {
                Image(systemName: timer.lastTask == nil ? "timer" : "checkmark.circle.fill")
                    .font(.system(size: 70))
                    .foregroundStyle(timer.lastTask == nil ? Color.accentColor : .green)
                    .padding(.top, 42)

                if let task = timer.lastTask {
                    VStack(spacing: 8) {
                        Text("Session Finished")
                            .font(.title.bold())
                        Text(task.content)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                    }

                    VStack(spacing: 12) {
                        Button {
                            timer.start(phase: .focus, minutes: focusMinutes, task: task)
                        } label: {
                            Label("Another Focus Session", systemImage: "brain.head.profile")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        .controlSize(.large)

                        HStack(spacing: 12) {
                            Button {
                                timer.start(phase: .shortBreak, minutes: shortBreakMinutes, task: task)
                            } label: {
                                Text("Short Break")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)

                            Button {
                                timer.start(phase: .longBreak, minutes: longBreakMinutes, task: task)
                            } label: {
                                Text("Long Break")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)
                        }
                        .controlSize(.large)

                        completeTodoistButton(task)
                    }
                } else {
                    VStack(spacing: 9) {
                        Text("No Active Session")
                            .font(.title2.bold())
                        Text("Choose a Todoist task to begin a \(focusMinutes)-minute focus session.")
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.secondary)
                    }
                }

                Button(action: onChooseTask) {
                    Label("Choose a Task", systemImage: "list.bullet")
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
            }
            .padding(24)
            .frame(maxWidth: 620)
            .frame(maxWidth: .infinity)
        }
    }

    private func completeTodoistButton(_ task: TodoistTask) -> some View {
        Button {
            isCompletingTask = true
            Task {
                do {
                    try await appState.todoist.closeTask(id: task.id)
                    todoistMessage = "“\(task.content)” was completed in Todoist."
                } catch {
                    todoistMessage = error.localizedDescription
                }
                isCompletingTask = false
            }
        } label: {
            HStack {
                if isCompletingTask { ProgressView() }
                Label("Complete Task in Todoist", systemImage: "checkmark.circle")
            }
        }
        .buttonStyle(.borderless)
        .disabled(isCompletingTask)
    }
}

