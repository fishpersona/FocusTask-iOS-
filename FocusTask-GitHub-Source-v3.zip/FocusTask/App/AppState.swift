import Foundation
import Combine

@MainActor
final class AppState: ObservableObject {
    @Published private(set) var isConnected: Bool
    @Published var connectionError: String?

    let todoist = TodoistAPI()

    init() {
        isConnected = KeychainStore.todoistToken != nil
    }

    func connect(token: String) async -> Bool {
        let cleaned = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleaned.isEmpty else {
            connectionError = "Enter your Todoist personal API token."
            return false
        }

        do {
            try await todoist.validate(token: cleaned)
            try KeychainStore.saveTodoistToken(cleaned)
            connectionError = nil
            isConnected = true
            return true
        } catch {
            connectionError = error.localizedDescription
            return false
        }
    }

    func disconnect() {
        KeychainStore.deleteTodoistToken()
        connectionError = nil
        isConnected = false
    }
}
