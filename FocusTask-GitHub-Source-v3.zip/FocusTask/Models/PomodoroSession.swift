import Foundation
import SwiftData

@Model
final class PomodoroSession {
    @Attribute(.unique) var id: UUID
    var taskId: String?
    var taskTitle: String
    var projectName: String?
    var startedAt: Date
    var endedAt: Date
    var plannedSeconds: Double
    var completedSeconds: Double
    var kind: String
    var outcome: String

    init(
        id: UUID = UUID(),
        taskId: String?,
        taskTitle: String,
        projectName: String?,
        startedAt: Date,
        endedAt: Date,
        plannedSeconds: Double,
        completedSeconds: Double,
        kind: String,
        outcome: String
    ) {
        self.id = id
        self.taskId = taskId
        self.taskTitle = taskTitle
        self.projectName = projectName
        self.startedAt = startedAt
        self.endedAt = endedAt
        self.plannedSeconds = plannedSeconds
        self.completedSeconds = completedSeconds
        self.kind = kind
        self.outcome = outcome
    }
}

