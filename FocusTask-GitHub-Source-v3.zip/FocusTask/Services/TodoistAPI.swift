import Foundation

actor TodoistAPI {
    private let baseURL = URL(string: "https://api.todoist.com/api/v1")!
    private let decoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return decoder
    }()

    func validate(token: String) async throws {
        _ = try await request(
            path: "projects",
            queryItems: [URLQueryItem(name: "limit", value: "1")],
            tokenOverride: token
        )
    }

    func fetchTasks() async throws -> [TodoistTask] {
        try await fetchAll(path: "tasks", as: TodoistTask.self)
    }

    func fetchProjects() async throws -> [TodoistProject] {
        try await fetchAll(path: "projects", as: TodoistProject.self)
    }

    func closeTask(id: String) async throws {
        let encodedId = id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? id
        _ = try await request(
            path: "tasks/\(encodedId)/close",
            method: "POST",
            tokenOverride: nil
        )
    }

    private func fetchAll<Value: Decodable>(
        path: String,
        as type: Value.Type
    ) async throws -> [Value] {
        var values: [Value] = []
        var cursor: String?

        repeat {
            var query = [URLQueryItem(name: "limit", value: "200")]
            if let cursor {
                query.append(URLQueryItem(name: "cursor", value: cursor))
            }

            let page = try await requestPage(
                path: path,
                queryItems: query,
                tokenOverride: nil,
                as: type
            )
            values.append(contentsOf: page.results)
            cursor = page.nextCursor
        } while cursor != nil

        return values
    }

    private func requestPage<Value: Decodable>(
        path: String,
        queryItems: [URLQueryItem],
        tokenOverride: String?,
        as type: Value.Type
    ) async throws -> PaginatedResponse<Value> {
        let data = try await request(
            path: path,
            queryItems: queryItems,
            tokenOverride: tokenOverride
        )
        do {
            return try decoder.decode(PaginatedResponse<Value>.self, from: data)
        } catch is DecodingError {
            throw TodoistAPIError.unexpectedData
        }
    }

    private func request(
        path: String,
        method: String = "GET",
        queryItems: [URLQueryItem] = [],
        tokenOverride: String?
    ) async throws -> Data {
        guard let token = tokenOverride ?? KeychainStore.todoistToken,
              !token.isEmpty else {
            throw TodoistAPIError.missingToken
        }

        let endpoint = baseURL.appending(path: path)
        guard var components = URLComponents(url: endpoint, resolvingAgainstBaseURL: false) else {
            throw TodoistAPIError.invalidURL
        }
        if !queryItems.isEmpty {
            components.queryItems = queryItems
        }
        guard let url = components.url else {
            throw TodoistAPIError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw TodoistAPIError.invalidResponse
        }

        guard 200..<300 ~= httpResponse.statusCode else {
            let message = String(data: data, encoding: .utf8) ?? "No response details"
            throw TodoistAPIError.httpStatus(httpResponse.statusCode, message)
        }

        return data
    }
}

enum TodoistAPIError: LocalizedError {
    case missingToken
    case invalidURL
    case invalidResponse
    case unexpectedData
    case httpStatus(Int, String)

    var errorDescription: String? {
        switch self {
        case .missingToken:
            return "Connect your Todoist account before refreshing tasks."
        case .invalidURL:
            return "FocusTask could not construct the Todoist request."
        case .invalidResponse:
            return "Todoist returned an unreadable response."
        case .unexpectedData:
            return "Todoist returned data in an unexpected format. FocusTask may need an update."
        case .httpStatus(let code, _):
            if code == 401 {
                return "Todoist rejected this API token. Check or replace it in Settings."
            }
            return "Todoist returned an error (HTTP \(code))."
        }
    }
}
