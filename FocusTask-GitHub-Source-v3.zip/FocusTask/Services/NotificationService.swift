import Foundation
import UserNotifications

enum NotificationService {
    static let timerNotificationId = "focus-task-active-timer"

    static func requestAuthorizationIfNeeded() async {
        let center = UNUserNotificationCenter.current()
        let settings = await center.notificationSettings()
        guard settings.authorizationStatus == .notDetermined else { return }
        _ = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
    }

    static func schedule(endDate: Date, phase: TimerPhase, taskTitle: String?) async {
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [timerNotificationId])

        let content = UNMutableNotificationContent()
        content.title = phase.completionTitle
        if phase == .focus, let taskTitle, !taskTitle.isEmpty {
            content.body = "Focus session finished: \(taskTitle)"
        } else {
            content.body = phase.completionBody
        }
        content.sound = .default

        let interval = max(1, endDate.timeIntervalSinceNow)
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false)
        let request = UNNotificationRequest(
            identifier: timerNotificationId,
            content: content,
            trigger: trigger
        )
        try? await center.add(request)
    }

    static func cancelTimerNotification() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(
            withIdentifiers: [timerNotificationId]
        )
    }
}

