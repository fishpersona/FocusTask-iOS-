import Foundation
import Combine

enum TimerPhase: String, Codable, CaseIterable, Sendable {
    case focus
    case shortBreak
    case longBreak

    var title: String {
        switch self {
        case .focus: "Focus"
        case .shortBreak: "Short Break"
        case .longBreak: "Long Break"
        }
    }

    var completionTitle: String {
        switch self {
        case .focus: "Focus session complete"
        case .shortBreak, .longBreak: "Break complete"
        }
    }

    var completionBody: String {
        switch self {
        case .focus: "Time for a break."
        case .shortBreak, .longBreak: "Ready for another focus session?"
        }
    }
}

struct ActiveTimerState: Codable, Equatable, Sendable {
    var phase: TimerPhase
    var task: TodoistTask?
    var projectName: String?
    var startedAt: Date
    var endDate: Date?
    var remainingWhenPaused: TimeInterval
    var plannedSeconds: TimeInterval
    var isRunning: Bool
}

struct TimerCompletion: Identifiable, Equatable, Sendable {
    let id: UUID
    let state: ActiveTimerState
    let endedAt: Date
    let completedSeconds: TimeInterval
    let outcome: String
}

@MainActor
final class TimerEngine: ObservableObject {
    @Published private(set) var state: ActiveTimerState?
    @Published private(set) var displayedRemaining: TimeInterval = 0
    @Published private(set) var completion: TimerCompletion?
    @Published private(set) var lastTask: TodoistTask?
    @Published private(set) var lastProjectName: String?

    private let defaultsKey = "activeTimerState.v1"
    private var ticker: Task<Void, Never>?

    init() {
        restore()
    }

    var progress: Double {
        guard let state, state.plannedSeconds > 0 else { return 0 }
        return min(1, max(0, 1 - displayedRemaining / state.plannedSeconds))
    }

    var formattedRemaining: String {
        let seconds = max(0, Int(ceil(displayedRemaining)))
        return String(format: "%02d:%02d", seconds / 60, seconds % 60)
    }

    func start(
        phase: TimerPhase,
        minutes: Int,
        task: TodoistTask?,
        projectName: String? = nil
    ) {
        let now = Date()
        let seconds = TimeInterval(max(1, minutes) * 60)
        let resolvedProjectName = projectName ?? lastProjectName
        let newState = ActiveTimerState(
            phase: phase,
            task: task,
            projectName: resolvedProjectName,
            startedAt: now,
            endDate: now.addingTimeInterval(seconds),
            remainingWhenPaused: seconds,
            plannedSeconds: seconds,
            isRunning: true
        )
        state = newState
        displayedRemaining = seconds
        if let task { lastTask = task }
        lastProjectName = resolvedProjectName
        persist()
        startTicker()

        Task {
            await NotificationService.requestAuthorizationIfNeeded()
            await NotificationService.schedule(
                endDate: newState.endDate ?? now,
                phase: phase,
                taskTitle: task?.content
            )
        }
    }

    func pause() {
        guard var current = state, current.isRunning else { return }
        current.remainingWhenPaused = remaining(for: current)
        current.endDate = nil
        current.isRunning = false
        state = current
        displayedRemaining = current.remainingWhenPaused
        ticker?.cancel()
        NotificationService.cancelTimerNotification()
        persist()
    }

    func resume() {
        guard var current = state, !current.isRunning else { return }
        current.endDate = Date().addingTimeInterval(current.remainingWhenPaused)
        current.isRunning = true
        state = current
        displayedRemaining = current.remainingWhenPaused
        persist()
        startTicker()

        Task {
            await NotificationService.requestAuthorizationIfNeeded()
            await NotificationService.schedule(
                endDate: current.endDate ?? Date(),
                phase: current.phase,
                taskTitle: current.task?.content
            )
        }
    }

    func cancel() {
        guard let current = state else { return }
        let elapsed = max(0, current.plannedSeconds - remaining(for: current))
        finish(current, completedSeconds: elapsed, outcome: "cancelled")
    }

    func acknowledgeCompletion() {
        completion = nil
    }

    private func startTicker() {
        ticker?.cancel()
        ticker = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                guard let self, let current = self.state, current.isRunning else { return }
                let remaining = self.remaining(for: current)
                self.displayedRemaining = remaining
                if remaining <= 0 {
                    self.finish(
                        current,
                        completedSeconds: current.plannedSeconds,
                        outcome: "completed"
                    )
                    return
                }
                try? await Task.sleep(nanoseconds: 250_000_000)
            }
        }
    }

    private func remaining(for state: ActiveTimerState) -> TimeInterval {
        if state.isRunning, let endDate = state.endDate {
            return max(0, endDate.timeIntervalSinceNow)
        }
        return max(0, state.remainingWhenPaused)
    }

    private func finish(
        _ finishedState: ActiveTimerState,
        completedSeconds: TimeInterval,
        outcome: String
    ) {
        ticker?.cancel()
        if outcome != "completed" {
            NotificationService.cancelTimerNotification()
        }
        state = nil
        displayedRemaining = 0
        UserDefaults.standard.removeObject(forKey: defaultsKey)
        if let task = finishedState.task { lastTask = task }
        lastProjectName = finishedState.projectName
        completion = TimerCompletion(
            id: UUID(),
            state: finishedState,
            endedAt: Date(),
            completedSeconds: completedSeconds,
            outcome: outcome
        )
    }

    private func persist() {
        guard let state,
              let data = try? JSONEncoder().encode(state) else {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            return
        }
        UserDefaults.standard.set(data, forKey: defaultsKey)
    }

    private func restore() {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let restored = try? JSONDecoder().decode(ActiveTimerState.self, from: data) else {
            return
        }

        lastTask = restored.task
        lastProjectName = restored.projectName
        let remaining = remaining(for: restored)
        if restored.isRunning, remaining <= 0 {
            finish(
                restored,
                completedSeconds: restored.plannedSeconds,
                outcome: "completed"
            )
        } else {
            state = restored
            displayedRemaining = remaining
            startTicker()
        }
    }
}
