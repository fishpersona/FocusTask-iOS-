#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
OUTPUT_DIR="${1:-$PROJECT_DIR/build}"
WORK_DIR="$(mktemp -d)"
DERIVED_DATA="$WORK_DIR/DerivedData"
PAYLOAD_DIR="$WORK_DIR/Payload"

cleanup() {
  rm -rf "$WORK_DIR"
}
trap cleanup EXIT

mkdir -p "$OUTPUT_DIR" "$PAYLOAD_DIR"

xcodebuild \
  -project "$PROJECT_DIR/FocusTask.xcodeproj" \
  -scheme FocusTask \
  -configuration Release \
  -sdk iphoneos \
  -destination "generic/platform=iOS" \
  -derivedDataPath "$DERIVED_DATA" \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  clean build

APP_PATH="$DERIVED_DATA/Build/Products/Release-iphoneos/FocusTask.app"
BINARY_PATH="$APP_PATH/FocusTask"

if [[ ! -d "$APP_PATH" || ! -f "$BINARY_PATH" ]]; then
  echo "The iPhone app was not produced at the expected location." >&2
  exit 1
fi

echo "Built application:"
file "$BINARY_PATH"
lipo -info "$BINARY_PATH"

ditto "$APP_PATH" "$PAYLOAD_DIR/FocusTask.app"

IPA_PATH="$OUTPUT_DIR/FocusTask-unsigned.ipa"
rm -f "$IPA_PATH"
(
  cd "$WORK_DIR"
  /usr/bin/zip -qry "$IPA_PATH" Payload
)

if [[ ! -s "$IPA_PATH" ]]; then
  echo "The IPA archive was not created." >&2
  exit 1
fi

echo "Created $IPA_PATH"

