# FocusTask

FocusTask is a private SwiftUI Pomodoro timer that connects a focus session to a Todoist task. It loads active tasks and projects, runs reliable foreground/background timers, delivers local notifications, stores focus history locally with SwiftData, and can optionally complete a selected task in Todoist.

FocusTask is an independent personal project and is not created by, affiliated with, or supported by Todoist.

## Requirements

- A Mac running a current version of Xcode
- iOS 17 or newer
- An Apple developer account
- A Todoist personal API token

## Install on your iPhone

1. Unzip the project and open `FocusTask.xcodeproj` in Xcode.
2. Select the **FocusTask** project in the navigator, then select the **FocusTask** target.
3. Open **Signing & Capabilities**.
4. Enable **Automatically manage signing** and select your developer team.
5. If Xcode reports that the bundle identifier is unavailable, change `com.alexfishburn.FocusTask` to a unique reverse-domain identifier of your choice.
6. Connect your iPhone, select it as the run destination, and press **Run**.
7. On first launch, paste your Todoist personal API token. The app validates it and stores it in the iOS Keychain.

For an exported development IPA, use **Product → Archive**, select the archive in Organizer, and choose **Distribute App → Development**. Direct installation from Xcode is the simplest option.

## Build an unsigned IPA with GitHub Actions

The included `Build Unsigned IPA` workflow compiles the project on GitHub's macOS runner. It does not require an Apple certificate because the resulting IPA is intentionally unsigned for signing through Feather or another signer afterward.

1. Create a private GitHub repository and place the contents of this `FocusTask` folder at the repository root.
2. Keep the default branch named `main`.
3. The first push automatically starts **Build Unsigned IPA**. You can also open **Actions → Build Unsigned IPA → Run workflow**.
4. When the job is green, open its run summary and download the `FocusTask-unsigned-ipa` artifact.
5. GitHub downloads the artifact as a ZIP. Extract it in the iOS Files app to reveal `FocusTask-unsigned.ipa`.
6. Import that IPA into Feather, select your certificate/profile, sign it, and install it.

No Todoist token, Apple certificate, provisioning profile, or signing password is needed in GitHub. The Todoist token is entered after the signed application is installed and is stored in the iPhone Keychain.

The workflow runs automatically when application source or the workflow changes. GitHub retains each generated IPA artifact for seven days.

## Todoist token

Find your personal API token in Todoist under **Settings → Integrations → Developer**. The token is deliberately not included in this source tree or its build settings.

Treat the token like a password. If it is ever exposed outside a trusted environment, revoke/regenerate it in Todoist and reconnect FocusTask using the replacement.

## Included functionality

- Todoist active-task and project retrieval through the current `/api/v1` API
- Today/overdue, all active, inbox, upcoming, and project scopes
- Local task search
- Focus, short-break, and long-break timers
- Pause, resume, cancellation, and state restoration after app suspension or relaunch
- Local completion notifications
- Local SwiftData session history and daily totals
- Optional Todoist task completion
- Adjustable timer lengths
- API-token storage in Keychain

## Architecture

- `TodoistAPI`: authenticated, cursor-paginated Todoist requests
- `TimerEngine`: absolute-end-time timer logic and session restoration
- `NotificationService`: local notification scheduling
- `KeychainStore`: device-only token storage
- `PomodoroSession`: local SwiftData history model
- SwiftUI views for setup, tasks, timer, history, and settings

## Current scope

This first release uses pull-to-refresh instead of Todoist webhooks and keeps Pomodoro history local. It does not require or contact an application server. A Lock Screen/Dynamic Island Live Activity and widgets can be added in a later release without changing the underlying timer/session model.
